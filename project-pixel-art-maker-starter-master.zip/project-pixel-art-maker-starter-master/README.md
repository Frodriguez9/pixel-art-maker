# Pixel Art Maker Project

This was the last project of my Intro to Programming Nanodegree with Udacity.

Udacity provided the HTML and CSS code, while I was tasked to develop the JavaScript
portion of the project. 

Please open 'designs.js' to see the code that I actually wrote.

## This project demonstrated my ability to:

- Use JavaSript to alter HTML and CSS Coding.

- Demonstrate my understanding of the DOM and how to manipulate Nodes and Elements.

- Use Event Listeners to triger actions.

- Create algorithms to successfully run the program without crashing.


## Note:

For specific, detailed instructions of the project, look at the project instructions in the [Udacity Classroom](https://classroom.udacity.com/me).
